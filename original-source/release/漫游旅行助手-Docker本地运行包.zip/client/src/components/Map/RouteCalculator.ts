import { useSettingsStore } from '../../store/settingsStore'
import { pluginsApi, mapsApi } from '../../api/client'
import type { DistanceUnit, RouteResult, RouteSegment, RouteWithLegs, Waypoint, RouteAnchors } from '../../types'
import { formatDistance } from '../../utils/units'
import { wgs84ToGcj02 } from './engines/amap'
import type { AvoidClass } from './valhallaRoute'
import { countRoute } from './routeUsageCounter'
import type { RouteUsageSurface } from '@trek/shared'

const OSRM_BASE = 'https://router.project-osrm.org/route/v1'

export class RoutingRefusedError extends Error {
  constructor(readonly status: number, readonly retryAfterMs: number | null) {
    super(status === 429 ? 'Routing rate limit reached' : 'Route could not be calculated')
    this.name = 'RoutingRefusedError'
  }

  get isRateLimit(): boolean {
    return this.status === 429 || this.status === 503
  }
}

// FOSSGIS hosts OSRM with real per-profile routing (car/foot/bike) — the
// project-osrm.org demo is car-only (it ignores the profile in the URL). Use
// the matching profile so walking routes follow footpaths, not the road network.
const OSRM_PROFILE_BASE: Record<'driving' | 'walking' | 'cycling', string> = {
  driving: 'https://routing.openstreetmap.de/routed-car/route/v1/driving',
  walking: 'https://routing.openstreetmap.de/routed-foot/route/v1/foot',
  cycling: 'https://routing.openstreetmap.de/routed-bike/route/v1/bike',
}

// Cache route responses keyed by the exact waypoint list. Routes are stable, so
// this avoids re-hitting the public OSRM demo server on every day switch / reorder.
const routeCache = new Map<string, RouteWithLegs>()
const ROUTE_CACHE_MAX = 200

/**
 * A route profile is either one of the built-in OSRM profiles or a plugin profile
 * key `plugin:<pluginId>/<profileId>` — the route toggle offers those for every
 * active routeProvider plugin, and calculateRouteWithLegs dispatches on the prefix.
 */
export type RouteProfileKey = 'driving' | 'walking' | 'cycling' | (string & {})

// The distance a requested route would have covered as the crow flies — the counter's
// km column, good enough for "how much routing does this instance do" volume math.
function haversineKm(a: Waypoint, b: Waypoint): number {
  const R = 6371
  const dLat = ((b.lat - a.lat) * Math.PI) / 180
  const dLng = ((b.lng - a.lng) * Math.PI) / 180
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(s))
}

/** Count one OSRM request for the usage counter (TT port of upstream 4.3.0 route-usage). */
function countOsrm(
  surface: RouteUsageSurface,
  profile: 'driving' | 'walking' | 'cycling',
  waypoints: readonly Waypoint[],
  response: Response,
): void {
  let km = 0
  for (let i = 1; i < waypoints.length; i++) km += haversineKm(waypoints[i - 1], waypoints[i])
  countRoute({
    profile,
    surface,
    selfHosted: !!useSettingsStore.getState().settings.routing_base_url?.trim(),
    waypoints: waypoints.length,
    km,
    failed: !response.ok,
  })
}

export function parsePluginProfile(profile: string): { pluginId: string; profileId: string } | null {
  if (!profile.startsWith('plugin:')) return null
  const rest = profile.slice('plugin:'.length)
  const slash = rest.indexOf('/')
  if (slash <= 0 || slash === rest.length - 1) return null
  return { pluginId: rest.slice(0, slash), profileId: rest.slice(slash + 1) }
}

/** Fetches a full route via OSRM and returns coordinates, distance, and duration estimates for driving/walking. */
export async function calculateRoute(
  waypoints: Waypoint[],
  profile: 'driving' | 'walking' | 'cycling' = 'driving',
  { signal }: { signal?: AbortSignal } = {}
): Promise<RouteResult> {
  if (!waypoints || waypoints.length < 2) {
    throw new Error('At least 2 waypoints required')
  }

  const coords = waypoints.map((p) => `${p.lng},${p.lat}`).join(';')
  const url = `${OSRM_BASE}/${profile}/${coords}?overview=full&geometries=geojson&steps=false`

  const response = await fetch(url, { signal })
  countOsrm('route', profile, waypoints, response)
  if (!response.ok) {
    throw new Error('Route could not be calculated')
  }

  const data = await response.json()

  if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
    throw new Error('No route found')
  }

  const route = data.routes[0]
  const coordinates: [number, number][] = route.geometry.coordinates.map(([lng, lat]: [number, number]) => [lat, lng])

  const distance: number = route.distance
  let duration: number
  if (profile === 'walking') {
    duration = distance / (5000 / 3600)
  } else if (profile === 'cycling') {
    duration = distance / (15000 / 3600)
  } else {
    duration = route.duration
  }

  const walkingDuration = distance / (5000 / 3600)
  const drivingDuration: number = route.duration

  return {
    coordinates,
    distance,
    duration,
    distanceText: formatRouteDistance(distance),
    durationText: formatDuration(duration),
    walkingText: formatDuration(walkingDuration),
    drivingText: formatDuration(drivingDuration),
  }
}

/**
 * Prepends a hotel→first-waypoint run and appends a last-waypoint→hotel run to the
 * day's activity runs, so the drawn route starts and ends at the day's accommodation
 * (matching the sidebar's hotel connectors). A bookend is only added when both its
 * hotel and the first/last located waypoint exist; passing nulls leaves `runs`
 * untouched. The shared first/last waypoint is repeated so the polylines join.
 */
export function withHotelBookends<T extends { lat: number; lng: number }>(
  runs: T[][],
  firstWay: T | undefined,
  lastWay: T | undefined,
  startHotel: T | null,
  endHotel: T | null,
): T[][] {
  const out: T[][] = []
  if (startHotel && firstWay) out.push([startHotel, firstWay])
  out.push(...runs)
  if (endHotel && lastWay) out.push([lastWay, endHotel])
  return out
}

export function generateGoogleMapsUrl(places: Waypoint[]): string | null {
  const valid = places.filter((p) => p.lat && p.lng)
  if (valid.length === 0) return null
  if (valid.length === 1) {
    return `https://www.google.com/maps/search/?api=1&query=${valid[0].lat},${valid[0].lng}`
  }
  const stops = valid.map((p) => `${p.lat},${p.lng}`).join('/')
  return `https://www.google.com/maps/dir/${stops}`
}

/**
 * AMap (高德地图) directions URL over the waypoints in planned order.
 *
 * Three facts about AMap's URI API shape this, all verified against the live
 * service rather than assumed:
 *
 *  1. `uri.amap.com/navigation` carries **no `coordinate` parameter** — unlike
 *     the marker URI, which honours `coordinate=wgs84`. Passing it there is
 *     silently ignored, so AMap read our WGS-84 values as GCJ-02 and every
 *     Chinese route landed a few hundred metres off. The waypoints are
 *     converted here instead, through the same Krasovsky transform the map
 *     renderer uses.
 *  2. `navigation`'s `via` takes **at most one** waypoint ("最多只支持添加一个
 *     途径点"). A `;`-joined list does not error — AMap folds the extra points
 *     into the first one's *name*, so a four-stop day quietly became a
 *     two-stop route. `ditu.amap.com/dir` is the endpoint the navigation URI
 *     itself redirects to, and it takes any number of indexed
 *     `via[i][lnglat]`/`via[i][name]` pairs, which is what this builds.
 *  3. In the `from=lng,lat,name` form a name containing a comma truncates the
 *     route at that comma. The indexed form carries each name as its own
 *     parameter, so "Cafe, Beijing" survives intact.
 *
 * A single stop stays a marker link, where `coordinate=wgs84` is the supported
 * declaration and AMap does the conversion itself.
 */
export function generateAmapMapsUrl(places: NamedWaypoint[]): string | null {
  const valid = places.filter((p) => p.lat != null && p.lng != null)
  if (valid.length === 0) return null
  const label = (p: NamedWaypoint) => p.name?.trim() || ''
  if (valid.length === 1) {
    const p = valid[0]
    const name = label(p)
    return `https://uri.amap.com/marker?position=${p.lng},${p.lat}&coordinate=wgs84&src=tt-travel-planner${name ? `&name=${encodeURIComponent(name)}` : ''}`
  }
  const gcj = (p: NamedWaypoint) => wgs84ToGcj02(Number(p.lng), Number(p.lat))
  const leg = (prefix: string, p: NamedWaypoint) => {
    const { lng, lat } = gcj(p)
    const name = label(p)
    return `&${prefix}%5Blnglat%5D=${lng},${lat}${name ? `&${prefix}%5Bname%5D=${encodeURIComponent(name)}` : ''}`
  }
  const [first, ...rest] = valid
  const last = rest.pop()!
  const vias = rest.map((p, i) => leg(`via%5B${i}%5D`, p)).join('')
  return `https://ditu.amap.com/dir?type=car${leg('from', first)}${vias}${leg('to', last)}`
}

/** A stop that can carry its name into a deep link that has somewhere to put one. */
export type NamedWaypoint = Waypoint & { name?: string | null }

/** TREK's route profiles in CoMaps' vocabulary; a plugin profile has no equivalent and drives. */
function coMapsRouteType(profile: RouteProfileKey): string {
  if (profile === 'walking') return 'pedestrian'
  if (profile === 'cycling') return 'bicycle'
  return 'vehicle'
}

/**
 * Open a day's stops in CoMaps for offline navigation (#1904).
 *
 * CoMaps has two links and they trade against each other. `route` builds real
 * turn-by-turn in the given travel mode but takes a start and a destination and
 * nothing between them; `map` takes any number of named pins but routes nothing.
 * So a two-stop day goes as a route — everything it has fits, mode included —
 * and a longer one goes as pins, because handing over the whole day and letting
 * CoMaps route leg by leg beats quietly dropping the middle of someone's plan.
 * A day that needs the full itinerary as one navigable track has the GPX export.
 *
 * https rather than `cm://` for the same reason as `getCoMapsUrlForPlace`.
 */
export function generateCoMapsUrl(places: NamedWaypoint[], profile: RouteProfileKey = 'driving'): string | null {
  const valid = places.filter((p) => p.lat != null && p.lng != null)
  if (valid.length === 0) return null
  const label = (p: NamedWaypoint) => encodeURIComponent(p.name?.trim() || `${p.lat},${p.lng}`)
  if (valid.length === 2) {
    const [from, to] = valid
    return `https://comaps.at/route?sll=${from.lat},${from.lng}&saddr=${label(from)}`
      + `&dll=${to.lat},${to.lng}&daddr=${label(to)}&type=${coMapsRouteType(profile)}`
  }
  const pins = valid.map((p) => `ll=${p.lat},${p.lng}&n=${label(p)}`).join('&')
  return `https://comaps.at/map?v=1&${pins}`
}

// Squared planar distance — enough for nearest-neighbor comparisons and cheaper than a full haversine.
function sqDist(a: Waypoint, b: Waypoint): number {
  return (a.lat - b.lat) ** 2 + (a.lng - b.lng) ** 2
}

// Length of visiting `order` in sequence, optionally pinned to a fixed start and/or end anchor.
// With start === end this is a closed loop back to the anchor (a day out from and back to the hotel).
function tourLength(order: Waypoint[], start?: Waypoint, end?: Waypoint): number {
  if (order.length === 0) return 0
  let total = 0
  if (start) total += Math.sqrt(sqDist(start, order[0]))
  for (let i = 0; i < order.length - 1; i++) total += Math.sqrt(sqDist(order[i], order[i + 1]))
  if (end) total += Math.sqrt(sqDist(order[order.length - 1], end))
  return total
}

// Greedy nearest-neighbor ordering, seeded at the start anchor when there is one.
function nearestNeighborOrder<T extends Waypoint>(valid: T[], start?: Waypoint): T[] {
  const visited = new Set<number>()
  const result: T[] = []
  let current: Waypoint
  if (start) {
    current = start
  } else {
    current = valid[0]
    visited.add(0)
    result.push(valid[0])
  }
  while (result.length < valid.length) {
    let nearestIdx = -1
    let minDist = Infinity
    for (let i = 0; i < valid.length; i++) {
      if (visited.has(i)) continue
      const d = sqDist(valid[i], current)
      if (d < minDist) { minDist = d; nearestIdx = i }
    }
    if (nearestIdx === -1) break
    visited.add(nearestIdx)
    current = valid[nearestIdx]
    result.push(valid[nearestIdx])
  }
  return result
}

// 2-opt: repeatedly reverse a sub-segment whenever it shortens the tour. This removes the crossings
// a pure nearest-neighbor pass leaves behind. The start/end anchors stay fixed, so a round trip
// (start === end) is untangled into a clean loop rather than an open path.
function twoOptImprove<T extends Waypoint>(order: T[], start?: Waypoint, end?: Waypoint): T[] {
  if (order.length < 3) return order
  let best = order
  let bestLen = tourLength(best, start, end)
  let improved = true
  while (improved) {
    improved = false
    for (let i = 0; i < best.length - 1; i++) {
      for (let j = i + 1; j < best.length; j++) {
        const candidate = best.slice(0, i).concat(best.slice(i, j + 1).reverse(), best.slice(j + 1))
        const len = tourLength(candidate, start, end)
        if (len < bestLen - 1e-12) {
          best = candidate
          bestLen = len
          improved = true
        }
      }
    }
  }
  return best
}

/**
 * Reorders waypoints to minimize travel distance: a nearest-neighbor pass for a good starting order,
 * then 2-opt to untangle crossings. Optional anchors (e.g. the day's accommodation) pin the route's
 * ends — start === end makes it a loop out from and back to the hotel; a transfer day runs start → end.
 */
export function optimizeRoute<T extends Waypoint>(places: T[], anchors: RouteAnchors = {}): T[] {
  const { start, end } = anchors
  const valid = places.filter((p) => p.lat && p.lng)
  if (valid.length <= 1) return places
  // Two unanchored stops have no meaningful order to optimize; anchors can still flip them.
  if (valid.length === 2 && !start && !end) return places

  const order = twoOptImprove(nearestNeighborOrder(valid, start), start, end)

  // A round trip's loop direction is arbitrary, so orient it to begin at the stop nearest the hotel —
  // that reads naturally as "leave the hotel, head to the closest place, …, come back".
  if (start && end && start.lat === end.lat && start.lng === end.lng && order.length > 1) {
    if (sqDist(order[order.length - 1], start) < sqDist(order[0], start)) order.reverse()
  }

  return order
}

/** Fetches per-leg distance/duration from OSRM and returns segment metadata (midpoints, walking/driving times). */
export async function calculateSegments(
  waypoints: Waypoint[],
  { signal }: { signal?: AbortSignal } = {}
): Promise<RouteSegment[]> {
  if (!waypoints || waypoints.length < 2) return []

  const coords = waypoints.map((p) => `${p.lng},${p.lat}`).join(';')
  const url = `${OSRM_BASE}/driving/${coords}?overview=false&geometries=geojson&steps=false&annotations=distance,duration`

  const response = await fetch(url, { signal })
  countOsrm('segments', 'driving', waypoints, response)
  if (!response.ok) throw new Error('Route could not be calculated')

  const data = await response.json()
  if (data.code !== 'Ok' || !data.routes?.[0]) throw new Error('No route found')

  const legs = data.routes[0].legs
  return legs.map((leg: { distance: number; duration: number }, i: number): RouteSegment => {
    const from: [number, number] = [waypoints[i].lat, waypoints[i].lng]
    const to: [number, number] = [waypoints[i + 1].lat, waypoints[i + 1].lng]
    const mid: [number, number] = [(from[0] + to[0]) / 2, (from[1] + to[1]) / 2]
    const walkingDuration = leg.distance / (5000 / 3600)
    return {
      mid, from, to,
      distance: leg.distance,
      duration: leg.duration,
      walkingText: formatDuration(walkingDuration),
      drivingText: formatDuration(leg.duration),
      distanceText: formatRouteDistance(leg.distance),
    }
  })
}

/**
 * One OSRM call per waypoint-run that returns BOTH the real road geometry (for the
 * map) and per-leg distance/duration (for the sidebar connectors). Results are cached
 * by the exact waypoint list. Throws on OSRM failure so callers can fall back to a
 * straight line.
 */
export async function calculateRouteWithLegs(
  waypoints: Waypoint[],
  { signal, profile = 'driving', tripId, dayId, avoid = [] }: {
    signal?: AbortSignal
    profile?: RouteProfileKey
    tripId?: number | string | null
    dayId?: number | null
    /** Road classes to weight away. Only the driving profile has any, and only Valhalla can. */
    avoid?: readonly AvoidClass[]
  } = {}
): Promise<RouteWithLegs> {
  if (!waypoints || waypoints.length < 2) {
    return { coordinates: [], distance: 0, duration: 0, legs: [] }
  }

  const coords = waypoints.map((p) => `${p.lng},${p.lat}`).join(';')
  // The cached result carries formatted leg distances, so the active distance unit is
  // part of the key — otherwise switching km↔mi would return stale text (#1300).
  // A plugin route is trip-/day-specific (it may return different charging stops for
  // the same coordinates on a different day), so its key includes tripId/dayId;
  // the built-in OSRM profiles are context-free and leave those out.
  const pluginScope = profile.startsWith('plugin:') ? `:${tripId ?? ''}:${dayId ?? ''}` : ''
  const cacheKey = `${profile}:${getDistanceUnit()}:${coords}${pluginScope}`
  const cached = routeCache.get(cacheKey)
  if (cached) return cached

  // Plugin profile (`plugin:<id>/<profile>`): the server invokes that routeProvider
  // and normalizes its answer; null means the provider failed or refused, and the
  // throw makes callers fall back to straight lines exactly like an OSRM outage.
  const pluginProfile = parsePluginProfile(profile)
  if (pluginProfile) {
    if (tripId == null) throw new Error('Plugin routing needs a trip context')
    const { route } = await pluginsApi.pluginRoute(pluginProfile.pluginId, pluginProfile.profileId, {
      tripId,
      dayId: dayId ?? null,
      waypoints: waypoints.map((p) => ({ lat: p.lat, lng: p.lng })),
    }, { signal })
    if (!route) throw new Error('No route found')
    const legs: RouteSegment[] = route.legs.map((leg, i): RouteSegment => {
      const from: [number, number] = [waypoints[i].lat, waypoints[i].lng]
      const to: [number, number] = [waypoints[i + 1].lat, waypoints[i + 1].lng]
      const mid: [number, number] = [(from[0] + to[0]) / 2, (from[1] + to[1]) / 2]
      return {
        mid, from, to,
        distance: leg.distance,
        duration: leg.duration,
        walkingText: formatDuration(leg.distance / (5000 / 3600)),
        drivingText: formatDuration(leg.duration),
        distanceText: formatRouteDistance(leg.distance),
        durationText: formatDuration(leg.duration),
        ...(leg.note ? { noteText: leg.note } : {}),
      }
    })
    const result: RouteWithLegs = {
      coordinates: route.coordinates,
      distance: route.distance,
      duration: route.duration,
      legs,
      ...(route.viaPoints.length ? { vias: route.viaPoints } : {}),
    }
    routeCache.set(cacheKey, result)
    if (routeCache.size > ROUTE_CACHE_MAX) {
      const oldest = routeCache.keys().next().value
      if (oldest !== undefined) routeCache.delete(oldest)
    }
    return result
  }

  // AMap profile (`amap:driving|walking|cycling`): routed server-side through
  // /api/maps/amap-route so the key never reaches the browser and every
  // polyline vertex arrives already converted GCJ-02→WGS-84. Real-traffic
  // durations come back per leg, formatted exactly like the OSRM branch below.
  if (profile.startsWith('amap:')) {
    const amapProfile = profile.slice('amap:'.length)
    if (amapProfile !== 'driving' && amapProfile !== 'walking' && amapProfile !== 'cycling') {
      throw new Error(`Unknown AMap profile: ${profile}`)
    }
    const route = await mapsApi.amapRoute(amapProfile, waypoints.map((p) => ({ lat: p.lat, lng: p.lng })), signal)
    const legs: RouteSegment[] = route.legs.map((leg, i): RouteSegment => {
      const from: [number, number] = [waypoints[i].lat, waypoints[i].lng]
      const to: [number, number] = [waypoints[i + 1].lat, waypoints[i + 1].lng]
      const mid: [number, number] = [(from[0] + to[0]) / 2, (from[1] + to[1]) / 2]
      return {
        mid, from, to,
        distance: leg.distance,
        duration: leg.duration,
        walkingText: formatDuration(leg.distance / (5000 / 3600)),
        drivingText: formatDuration(leg.duration),
        distanceText: formatRouteDistance(leg.distance),
        durationText: formatDuration(leg.duration),
      }
    })
    const result: RouteWithLegs = { coordinates: route.coordinates, distance: route.distance, duration: route.duration, legs }
    routeCache.set(cacheKey, result)
    if (routeCache.size > ROUTE_CACHE_MAX) {
      const oldest = routeCache.keys().next().value
      if (oldest !== undefined) routeCache.delete(oldest)
    }
    return result
  }

  const osrmProfile = (profile === 'walking' || profile === 'cycling') ? profile : 'driving'
  const url = `${OSRM_PROFILE_BASE[osrmProfile]}/${coords}?overview=full&geometries=geojson&annotations=distance,duration`
  const response = await fetch(url, { signal })
  countOsrm('legs', osrmProfile as 'driving' | 'walking' | 'cycling', waypoints, response)
  if (!response.ok) throw new Error('Route could not be calculated')

  const data = await response.json()
  if (data.code !== 'Ok' || !data.routes?.[0]) throw new Error('No route found')

  const route = data.routes[0]
  const coordinates: [number, number][] = route.geometry.coordinates.map(
    ([lng, lat]: [number, number]) => [lat, lng]
  )
  const legs: RouteSegment[] = (route.legs || []).map(
    (leg: { distance: number; duration: number }, i: number): RouteSegment => {
      const from: [number, number] = [waypoints[i].lat, waypoints[i].lng]
      const to: [number, number] = [waypoints[i + 1].lat, waypoints[i + 1].lng]
      const mid: [number, number] = [(from[0] + to[0]) / 2, (from[1] + to[1]) / 2]
      const walkingDuration = leg.distance / (5000 / 3600)
      return {
        mid, from, to,
        distance: leg.distance,
        duration: leg.duration,
        walkingText: formatDuration(walkingDuration),
        drivingText: formatDuration(leg.duration),
        distanceText: formatRouteDistance(leg.distance),
        durationText: formatDuration(leg.duration),
      }
    }
  )

  const result: RouteWithLegs = { coordinates, distance: route.distance, duration: route.duration, legs }
  routeCache.set(cacheKey, result)
  if (routeCache.size > ROUTE_CACHE_MAX) {
    const oldest = routeCache.keys().next().value
    if (oldest !== undefined) routeCache.delete(oldest)
  }
  return result
}

function getDistanceUnit(): DistanceUnit {
  return useSettingsStore.getState().settings.distance_unit === 'imperial' ? 'imperial' : 'metric'
}

function formatRouteDistance(meters: number): string {
  const unit = getDistanceUnit()
  if (unit === 'metric' && meters < 1000) {
    return `${Math.round(meters)} m`
  }
  return formatDistance(meters / 1000, unit)
}

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  if (h > 0) {
    return `${h} h ${m} min`
  }
  return `${m} min`
}

export interface RouteAlternative {
  coordinates: [number, number][]
  distance: number
  duration: number
  /** Where this route differs most from the first one — the point that would pin it. */
  divergence: { lat: number; lng: number } | null
  /** Set when this way exists because a road class was left out of it. */
  avoids?: AvoidClass
  /**
   * Which engine priced this route, when it was not the one that priced the rest.
   *
   * Absent for everything OSRM answered, which is every route in a list except the
   * avoidance offer on a default install. It exists because the two engines do not
   * agree on speed: measured over twelve European legs the per-leg drive times run
   * from 14.7 % under OSRM's to 13.2 % over, and the sign depends on the region:
   * Valhalla is faster on Spanish autovía and slower through a city. So a figure from
   * one of them subtracted from a figure from the other is not a difference in
   * driving time, it is the gap between two speed models, and the reader has no way
   * of telling the two apart.
   */
  engine?: 'valhalla'
}

export async function calculateAlternatives(
  from: Waypoint,
  to: Waypoint,
  profile: 'driving' | 'walking' | 'cycling' = 'driving',
  { signal, limit = 3 }: { signal?: AbortSignal; limit?: number } = {},
): Promise<RouteAlternative[]> {
  const coords = `${from.lng},${from.lat};${to.lng},${to.lat}`
  const response = await fetch(`${OSRM_BASE}/${profile}/${coords}?alternatives=${limit}&overview=full&geometries=geojson`, { signal })
  if (!response.ok) throw new RoutingRefusedError(response.status, null)
  const data = await response.json()
  if (data.code !== 'Ok' || !Array.isArray(data.routes)) return []
  return data.routes.map((route: { geometry?: { coordinates?: [number, number][] }; distance: number; duration: number }) => ({
    coordinates: (route.geometry?.coordinates ?? []).map(([lng, lat]) => [lat, lng] as [number, number]),
    distance: route.distance,
    duration: route.duration,
    divergence: null,
  }))
}
