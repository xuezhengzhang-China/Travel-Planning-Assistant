import { test, clearNotices, expect, readSeed, SHOT_LANG } from './shot'

/**
 * Modals and dialogs.
 *
 * Captured as element screenshots (not full page) so the wiki gets the dialog
 * itself rather than a dimmed backdrop with a small box in the middle. Each one
 * asserts the dialog is actually open first — a missed click would otherwise
 * silently produce a screenshot of the page behind it.
 */

type ScreenshotSeed = { tripId: number }
const seed = (): ScreenshotSeed => readSeed<ScreenshotSeed>()

/**
 * The shared Modal (client/src/components/shared/Modal.tsx) sets neither
 * role="dialog" nor aria-modal, so there is no accessible role to query — the
 * backdrop class is the only stable hook. Target its child, which is the panel
 * itself, so the capture excludes the dimmed backdrop.
 */
function dialog(page: import('@playwright/test').Page) {
  return page.locator('.trek-modal-backdrop > div').first()
}

test('create trip modal — with the new currency field', async ({ page, shot }) => {
  await page.goto('/dashboard')
  await clearNotices(page)
  await page.getByRole('button', { name: SHOT_LANG === 'zh' ? /新建旅行/ : /new trip/i }).first().click()
  await expect(dialog(page)).toBeVisible()
  await shot.element('TripCreate', dialog(page))
})

test('share dialog', async ({ page, shot }) => {
  await page.goto(`/trips/${seed().tripId}`)
  await clearNotices(page)
  await page.getByRole('button', { name: SHOT_LANG === 'zh' ? /分享/ : /share/i }).first().click()
  await expect(dialog(page)).toBeVisible()
  await shot.element('Share', dialog(page))
})
